const express = require('express');
const http = require('http');
const path = require('path');
const socketio = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = socketio(server);

// Set static folder
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

var rooms = {};

io.on('connection', socket => {
    socket.on('join-room', (roomId, userId, socketId) => {
		socket.join(roomId);
		socket.to(roomId).emit('user-connected', userId, "socket.id: ", socketId);
		console.log("join room event");
		socket.on('disconnect', () => {
			// filter out disconnected user
			rooms[roomId] = rooms[roomId].filter(x => x !== userId);
			console.log("User ", userId, "has left room: ", roomId);
			io.to(roomId).emit('user-disconnected', userId, rooms[roomId])
			// rooms[roomId].remove(userData);
		})
	})
});

server.listen(4000, () => {
    console.log('listening on *:4000');
});