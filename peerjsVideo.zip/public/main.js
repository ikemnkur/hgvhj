var PID = "peer" + Math.ceil(Math.random() * 1000);
// const peer = new Peer(peerID);
const peer = new Peer(PID);
var currentCall = {};
peer.on("open", function (id) {
    document.getElementById("uuid").textContent = id;
    console.log("peer open event (id):", id);
});

var Room;
var socketid;
const socket = io("/");

socket.on("connect", () => {
    console.log(`you connected with socket.id ${videoSocket.id}`);
    socketid = socket.id;
    // Join chatroom
    socket.emit("join-room", { roomID, PID, socketid });
})


socket.on("user-disconnect", (userId, rooms) => {
    console.log(`User "${userId}" has disconnected`)
    console.log("Current users in room:", rooms);
    Room = rooms;
})

function run() {

    callUser();
}


// Making A Call
// To make a call, we need to grab the id entered by the user, and use the peer.call method to make a connection. We also need to provide our video and audio stream. We can use the MediaStream API to get the device camera and microphone. Once the other user answers our call, we can play the remote video.

async function callUser() {
    // get the id entered by the user
    const peerId = document.querySelector("input").value;
    // grab the camera and mic
    // const stream = await navigator.mediaDevices.getUserMedia({
    //     video: true,
    //     audio: true,
    // });
    const myStream = document.getElementById("video").srcObject;
    // switch to the video call and play the camera preview
    //   document.getElementById("menu").style.display = "none";
    // document.getElementById("live").style.display = "block";
    // document.getElementById("local-video").srcObject = stream;
    // document.getElementById("local-video").play();
    if (1) {
        let div = document.createElement("div");
        let video = document.createElement("video");
        let header = document.createElement("header");
        header.innerText = title;
        video.id = title;
        video.srcObject = myStream;
        video.play();
        let livefeedDiv = document.getElementById("live");
        div.appendChild(header);
        div.appendChild(video);
        livefeedDiv.appendChild(div);
    }

    // make the call
    const call = peer.call(peerId, stream);
    call.on("stream", (stream) => {

        let title = "video#" + call.peer;
        if (document.getElementById(title) == null) { //check for duplicates
            // when we receive the remote stream, play it
            let div = document.createElement("div");
            let video = document.createElement("video");
            let header = document.createElement("header");
            header.innerText = title;
            video.id = title;
            video.srcObject = stream;
            video.play();
            let livefeedDiv = document.getElementById("live");
            div.appendChild(header);
            div.appendChild(video);
            livefeedDiv.appendChild(div);
        }


        // document.getElementById("remote-video").srcObject = stream;
        // document.getElementById("remote-video").play();
    });

    call.on("data", (stream) => {
        let title = "video#" + call.peer;
        if (document.getElementById(title) == null) { //check for duplicates
            // when we receive the remote stream, play it
            let div = document.createElement("div");
            let video = document.createElement("video");
            let header = document.createElement("header");
            header.innerText = title;
            video.id = title;
            video.srcObject = stream;
            video.play();
            let livefeedDiv = document.getElementById("live");
            div.appendChild(header);
            div.appendChild(video);
            livefeedDiv.appendChild(div);
        }


        // document.querySelector("#remote-video").srcObject = stream;
    });
    call.on("error", (err) => {
        console.log(err);
    });
    call.on('close', () => {
        endCall(call.peer)
    })
    // save the close function
    currentCall[call.peer] = call;
}

// Answering A Call
// When a call is made to our UUID, we receive a call event on our peer object, we can then ask the user if they want to accept the call or not. If they accept the call, we need to grab the user’s video and audio inputs, and send those to the caller. If the call is rejected, we can close the connection.

peer.on("call", (call) => {
    if (confirm(`Accept call from ${call.peer}?`)) {
        // grab the camera and mic
        navigator.mediaDevices
            .getUserMedia({ video: true, audio: true })
            .then((GUMstream) => {
                const myStream = document.getElementById("video").srcObject;
                // switch to the video call and play the camera preview
                // document.getElementById("local-video").srcObject = stream;
                // document.getElementById("local-video").play();
                // play the local preview
                if (1) {
                    let div = document.createElement("div");
                    let video = document.createElement("video");
                    let header = document.createElement("header");
                    header.innerText = title;
                    video.id = title;
                    video.srcObject = myStream;
                    video.play();
                    let livefeedDiv = document.getElementById("live");
                    div.appendChild(header);
                    div.appendChild(video);
                    livefeedDiv.appendChild(div);
                }

                // document.querySelector("#local-video").srcObject = stream;
                // document.querySelector("#local-video").play();
                // answer the call
                call.answer(myStream);
                //remove the preview stream
                document.getElementById('video').style.display = "none";
                // save the close function
                currentCall[call.peer] = call;
                // change to the video view
                // document.querySelector("#menu").style.display = "none";
                // document.querySelector("#live").style.display = "block";
                call.on("stream", (remoteStream) => {
                    let title = "video#" + call.peer;
                    if (document.getElementById(title) == null) {
                        // when we receive the remote stream, play it
                        let div = document.createElement("div");
                        let video = document.createElement("video");
                        let header = document.createElement("header");
                        header.innerText = title;
                        video.id = title;
                        video.srcObject = remoteStream;
                        video.play();
                        let livefeedDiv = document.getElementById("live");
                        div.appendChild(header);
                        div.appendChild(video);
                        livefeedDiv.appendChild(div);
                    }


                    //   document.getElementById("remote-video").srcObject = remoteStream;
                    //   document.getElementById("remote-video").play();
                });
            })
            .catch((err) => {
                console.log("Failed to get local stream:", err);
            });
    } else {
        // user rejected the call, close it
        call.close();
    }
});

// Ending The Call
// When the call is over the user can click the `End call` button to terminate the connection. Then, we can show the menu once again.

function endCall(peerid) {
    // Go back to the menu
    document.querySelector("#menu").style.display = "block";
    document.querySelector("#live").style.display = "none";
    // If there is no current call, return
    if (!currentCall[peerid]) return;
    // Close the call, and reset the function
    try {
        currentCall[peerid].close();
    } catch { }
    currentCall[peerid] = undefined;
}

// Conclusion
// The finished product
// The finished product, with 2 inactive OBS cameras
// Congratulations! We have create a real-time video chat application using PeerJS. This is only a brief introduction to PeerJS and WebRTC. But if you wish to learn more, check out these links.

// PeerJS.
// WebRTC | MDN
// Challenge
// This was just a simple app, so here are some challenges to get you practicing your new PeerJS skills.

// Make a proper menu, give it some style.
// Add usernames so people know who is calling them.
// Add proper support for audio only calls, so people can talk without needing a camera.
// Setup your own PeerJS server for handling connection requests.
// No rights reserved

//  by the author.

